"""
Set of custom functions providing metrics to evaluate our validation set.

Includes:
- shape-wise accuracy
- image-wise accuracy
- precision, recall and F1-score

Author:
Alexandre Zouaoui

Notes:
* We consider a prediction to fall under the *False Positive* (FP) category whenever it predicted a number of shape occurrences higher than the ground truth. The number of FP is equal to the absolute difference.
* Similarly we consider a prediction to be *False Negative* (FN) whenever it predicted a number of shape occurrences lower than the ground truth. The number of FN is equal to the absolute difference.
* Finally we consider a prediction to be a *True Positive* (TP) whenever the number of occurrences predicted is equal to the ground truth. The number of TP is equal to the value of ground truth occurrences.

* All of this is obviously flawed since we are not asked nor given the shapes bounding boxes.
"""

# Imports
# Numerical data handling package
import numpy as np

def shape_wise_accuracy(Y, Y_pred):
    """
    Compute the accuracy over the total number
    of successfully counted shapes in the evaluation set
    
    Parameters
    ------------
    - Y : numpy.ndarray
        Ground Truth array (1000x3)
        containing the number of occurences
        for each shape (square, circle and triangle)
        for each image sample
        
    - Y_pred : numpy.ndarray
        Predicted shape occurences number
        for each image sample
        
    Returns
    ------------
    - accuracy : float (between 0.0 and 1.0) 
    """
    # Convert integers to 32 bits to prevent 8 bits looping when substracting
    gt = Y.astype(np.int32)
    pred = Y_pred.astype(np.int32)
    # Counter number of 0 in the array difference over the total number of scores
    accuracy = dict(zip(*np.unique(gt - pred, return_counts=True)))[0] / float(3 * gt.shape[0])
    
    return accuracy

def image_wise_accuracy(Y, Y_pred):
    """
    Compute the accuracy over the total number of images
    where all shapes were successfully counted
    
    Parameters
    ------------
    - Y : numpy.ndarray
        Ground Truth array (1000x3)
        containing the number of occurences
        for each shape (square, circle and triangle)
        for each image sample
        
    - Y_pred : numpy.ndarray
        Predicted shape occurences number
        for each image sample
        
    Returns
    ------------
    - accuracy : float (between 0.0 and 1.0)
    """
    # Convert integers to 32 bits to prevent 8 bits looping when substracting
    gt = Y.astype(np.int32)
    pred = Y_pred.astype(np.int32)
    # Compute accuracy as number of [0, 0, 0] over total number of samples
    accuracy = sum([1 for a in (Y - Y_pred) if not a.any()]) / float(gt.shape[0])
    
    return accuracy

def custom_precision_recall(y, y_pred):
    """
    Compute precision and recall metrics by comparing
    ground truth to prediction output
    
    Parameters
    ------------
    - y : numpy.ndarray
        Ground Truth array (1000x1)
        containing the number of occurences
        for each image 
        (either square, circle and triangle)
        
    - y_pred : numpy.ndarray
        Predicted given shape occurences number
        for each image sample
        
    Returns
    ------------
    - precision : float (between 0.0 and 1.0)
        Prediction metric defined as TP / (TP + FN)
        
    - recall : float (between 0.0 and 1.0)
        Prediction metric defined as TP / (TP + FP)
        
    - f1_score : float (between 0.0 and 1.0)
        Prediction metric defined as (2 / ((1 / precision) + (1 / recall)))
    """
    # Convert integers to 32 bits to prevent 8 bits looping when substracting
    gt = y.astype(np.int32)
    pred = y_pred.astype(np.int32)
    
    # True Positive
    tp_mask = np.where(gt - pred == 0)
    TP = sum(gt[tp_mask])
    
    # False Positive
    fp_mask = np.where(gt - pred < 0)
    FP = sum(abs(gt - pred)[fp_mask])
    
    # False Negative
    fn_mask = np.where(gt - pred > 0)
    FN = sum((gt - pred)[fn_mask])
    
    # Compute precision
    precision = 0. if (TP + FN) == 0 else TP / (TP + FN)
    # Compute recall
    recall = 0. if (TP + FP) == 0 else TP / (TP + FP)
    # Compute F1-score
    f1_score = 0. if (precision == 0. or recall == 0.) else 2 / ((1 / precision) + (1 / recall))  
    
    return precision, recall, f1_score


