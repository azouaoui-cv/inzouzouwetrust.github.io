"""
Implement ShapeDetector class to detect either rectangles or triangles

Author: Alexandre Zouaoui
Largely inspired by Adrian Roseborck's tutorial on OpenCV shape detection
https://www.pyimagesearch.com/2016/02/08/opencv-shape-detection/
"""


# Import OpenCV (version 3.4.0)
import cv2

class ShapeDetector:
    def __init__(self):
        pass
    
    def detect(self, contour, eps=0.03, thresh_p=50):
        """
        Instance public class detecting contour shape as either square, triangle
        or leaving it unidentified
        
        Parameters
        --------------
        - contour : numpy.ndarray
            Contour retrieved by ``cv2.findContours``
            
        - eps : float (optional)
            factor to be used in ``cv2.approxPolyDP``
            to compute the contour perimeter ratio
            Traditionally between 0.01 and 0.05
            Set to 0.03 by default
            
        - thresh_p : integer (optional)
            perimeter threshold set to avoid noisy blobs
            Used in filtering contours whose perimeter is too low
            Set to 50 by default
        
        Returns
        --------------
        - shape : string
            String indicating the contour shape.
            Either 'triangle', 'square' or 'unidentified'
        """
        # Initialize the shape name and approximate the contour
        shape = "unidentified"
        perimeter = cv2.arcLength(contour, True)
        approximation = cv2.approxPolyDP(contour, eps * perimeter, True)
        
        n_vertices = 0 if approximation is None else len(approximation)
        
        # Threshold on perimeter to avoid noisy blobs
        if perimeter > thresh_p:
            
            # if the approximation has 3 edges, it is a triangle
            if n_vertices == 3:
                shape = "triangle"

            # if the approximation has 4 edges, it might be a square
            elif n_vertices == 4:
                # Compute the bouding box of the contour and the aspect ratio
                x, y, w, h = cv2.boundingRect(approximation)
                ratio = w / float(h)

                # If the aspect ratio is close to 1, it is a square
                shape = "square" if ratio >= 0.95 and ratio <= 1.05 else "unidentified"

            # Return the name of the shape
        return shape