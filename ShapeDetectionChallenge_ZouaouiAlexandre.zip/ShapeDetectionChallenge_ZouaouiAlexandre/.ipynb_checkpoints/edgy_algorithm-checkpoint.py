#!/usr/bin/env python
"""
Usage:
    ./edgy_algorithm.py <image path string>
Returns:
    Three integers in a comma-separated string
    <int>, <int>, <int>
Important:
    You may need to upgrade your OpenCV2 package version
    ``pip install --upgrade opencv-python``
Note: 
    For implementation details launch Shape_Recognition_Notebook.ipynb
Author: 
    Alexandre Zouaoui
"""

# Standard library packages
import sys
import os

# Open CV2 (/!\ version 3.4.0 /!\)
import cv2

# Custom Detector
from shape_recognition.shapedetector import ShapeDetector

if __name__ == "__main__":
    # Check command line arguments
    if len(sys.argv) != 2:
        print(__doc__)
        sys.exit(1)
        
    file_path = sys.argv[1]
    if not os.path.exists(file_path):
        raise OSError("File not found ('%s')" % file_path)
        sys.exit(1)
        
    ### PREPROCESSING ###
        
    # Load image into grayscale
    im_g = cv2.imread(file_path, cv2.IMREAD_GRAYSCALE)
    
    # Smoothing
    im_g = cv2.medianBlur(im_g, 5)
    
    # Apply binary threshold
    thresh, im_bw = cv2.threshold(im_g, 128, 255, cv2.THRESH_BINARY | cv2.THRESH_OTSU)
    
    ### CIRCLES DETECTION ###
    
    # Compute circles using Hough Transform
    circles = cv2.HoughCircles(im_g.copy(), cv2.HOUGH_GRADIENT, dp=1, 
                               minDist=50, param1=70, param2=30,
                               minRadius=10, maxRadius=100)
    # Retrieve number of circles
    n_circles = 0 if circles is None else min(circles.shape[1], 7) # max number of circle occs in training set
    
    ### SQUARES DETECTION ###
    
    # Instantiate Shape Detector
    shape_detector = ShapeDetector()
    
    # Find contours
    contours = cv2.findContours(im_bw.copy(), cv2.RETR_EXTERNAL,
                               cv2.CHAIN_APPROX_SIMPLE)[1]
    
    
    # Retrieve shapes list
    shapes = [shape_detector.detect(c, 0.04, 70) for c in contours] # Squares-optimized hyper-parameters 
    # Retrieve number of squares
    n_squares = min(shapes.count("square"), 4) # max number of square occs in training set
    
    
    # Retrieve shapes list
    shapes = [shape_detector.detect(c, 0.08, 50) for c in contours] # Triangle-optimized hyper-parameters
    # Retrieve number of triangles
    n_triangles = min(shapes.count("triangle"), 5) # max number of triangle occs in training set
    
    ### OUTPUT GENERATION ###
    
    prediction = ', '.join([str(n_squares), str(n_circles), str(n_triangles)])
    
    print(prediction)