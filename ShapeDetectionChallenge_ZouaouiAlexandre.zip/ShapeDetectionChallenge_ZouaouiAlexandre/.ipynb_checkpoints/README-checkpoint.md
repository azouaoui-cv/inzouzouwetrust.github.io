# Shape Recognition Interview Challenge Solution


I had 48 hours to implement a solution to solve a shape recognition challenge.


**Usage:**

Type in a command prompt the following line:

``./edgy_algorithm.py <image path string>``

Output consists in three integers in a comma-separated string respectively counting the number of **squares**, **circles** and **triangles**:

``<int>, <int>, <int>``

/!\ **Important** /!\

You may need to upgrade your OpenCV package version to ``'3.4.0'`` by running:

``pip install --upgrade opencv-python``

**Implementation:**

* I opted for an *image processing heuristics* approach, leveraging **OpenCV** tools such as Hough's Transform and Contours Search.

* ``edgy_algorithm.py`` uses a custom Python module to detect squares and triangles (``shape_recognition.shapedetector.py``).

* I provided my own metrics to compute the shape-wise and image-wise accuracies in the custom Python module named ``shape_recognition.metrics``. See the functions documentation for implementation details.


**Details:**

I cover the choices I have made in great details in the ``Shape_Recognition_Notebook.ipynb`` Jupyter notebook. It includes:
* Data Exploration
  * Data Visualization
  * Labels Distribution
  * Data Exploration Conclusions
  
* List of challenges faced
  * Preprocessing
  * Modelisation
  * Detection

* Shape Detection Pipeline description
  * Image Preprocessing
  * Circles Detection
  * Squares Detection
  * Triangles Detection
  * Output formatting

* Evaluation on a subset of the training samples
  * Prediction Distribution
  * Metrics
    * Accuracy
      * Shape-wise
      * Image-wise
    * Precision, Recall, F1-score

* Hyper-parameters optimization
* Final evaluation